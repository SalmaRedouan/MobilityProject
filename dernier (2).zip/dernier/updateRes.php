<?php include 'php/updateRes.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Modifier</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="styl.css">
</head>
<body>
	<div class="container">
		<form action="php/updateRes.php" 
		      method="post">
            
		   <h4 class="display-4 text-center">Modifier</h4><hr><br>
		   <?php if (isset($_GET['error'])) { ?>
		   <div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
		    </div>
		   <?php } ?>
		   <div class="form-group">
		     <label for="name">Nom complet</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="nom" 
		           value="<?=$row['nom'] ?>" >
		   </div>
		   

		   <div class="form-group">
		     <label for="name">Destinataire</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="destinataire" 
		           value="<?=$row['destinataire'] ?>" >
		   </div>
		   <div class="form-group">
		     <label for="name">Message de choix</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="message" 
		           value="<?=$row['message'] ?>" >
		   </div>
		   <div class="form-group">
		     <label for="name">Affectation finale</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="resultat" 
				   
		           value="<?=$row['resultat'] ?>" >
		   </div>
		  
		   <input type="text" 
		          name="id"
		          value="<?=$row['id']?>"
		          hidden >

		   <button type="submit" 
		           class="btn btn-primary"
		           name="update">Modifier</button>
		    <a href="visualiserFinal.php" class="link-primary">Visualiser</a>
	    </form>
	</div>
</body>
</html>