<?php include 'php/updateC.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Modifier</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="styl.css">
</head>
<body>
	<div class="container">
		<form action="php/updateC.php" 
		      method="post">
            
		   <h4 class="display-4 text-center">Modifier</h4><hr><br>
		   <?php if (isset($_GET['error'])) { ?>
		   <div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
		    </div>
		   <?php } ?>
		   <div class="form-group">
		     <label for="name">Nom de l'école</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="name" 
		           value="<?=$row['name'] ?>" >
		   </div>
		   

		   <div class="form-group">
		     <label for="email">Email de l'école</label>
		     <input type="email" 
		           class="form-control" 
		           id="email" 
		           name="email" 
		           value="<?=$row['email'] ?>" >
		   </div>
		   <div class="form-group">
		     <label for="name">Option</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="option" 
		           value="<?=$row['option'] ?>" >
		   </div>
		   <div class="form-group">
		     <label for="name">Nombre de place</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="nombre" 
		           value="<?=$row['nombre'] ?>" >
		   </div>
		   <div class="form-group">
		     <label for="name">Commentaire</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="comment" 
		           value="<?=$row['comment'] ?>" >
		   </div>
		   <div class="form-group">
		     <label for="name">Type de mobilité</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="type" 
		           value="<?=$row['type'] ?>" >
		   </div>
		   <div class="form-group">
		     <label for="name">Observations</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="observation" 
		           value="<?=$row['observation'] ?>"> 
		   </div>
		   <br>
         
		   <div class="form-group">
		   

<h6> Veuillez choisir les filières concernées par l'offre </h6> <br>
<p>
	<input type="checkbox" name="connaitre[]" value="ASEDS" id="name" /> <label for="site">ASEDS </label><br />
	<input type="checkbox" name="connaitre[]" value="DATA" id="name" /> <label for="tourisme">DATA</label><br />
	<input type="checkbox" name="connaitre[]" value="SMART" id="name" /> <label for="rs">SMART</label><br />
	<input type="checkbox" name="connaitre[]" value="ICCN" id="name" /> <label for="brochure">ICCN</label><br />
	<input type="checkbox" name="connaitre[]" value="CLOUD" id="name" /> <label for="brochure">CLOUD</label><br />
	<input type="checkbox" name="connaitre[]" value="AMOA" id="name" /> <label for="brochure">AMOA</label><br />
	<input type="checkbox" name="connaitre[]" value="SISNUM" id="name" /> <label for="brochure">SISNUM</label><br />
 
</p> </div>
<div class="form-group">
<label for="tentacles"> Nombre des places par filière réspectivement</label>
<br><br>

<input type="number" id="tentacles" name="nb[]"
min="0" max="100">
<input type="number" id="tentacles" name="nb[]"
min="0" max="100">
<input type="number" id="tentacles" name="nb[]"
min="0" max="100">
<input type="number" id="tentacles" name="nb[]"
min="0" max="100">
<input type="number" id="tentacles" name="nb[]"
min="0" max="100">
<input type="number" id="tentacles" name="nb[]"
min="0" max="100">
<input type="number" id="tentacles" name="nb[]"
min="0" max="100">
 </div>
		   <input type="text" 
		          name="id"
		          value="<?=$row['id']?>"
		          hidden >

		   <button type="submit" 
		           class="btn btn-primary"
		           name="update">Modifier</button>
		    <a href="readCo.php" class="link-primary">Visualiser</a>
	    </form>
	</div>
</body>
</html>