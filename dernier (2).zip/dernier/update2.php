<?php include 'php/update2.php'; ?>
<!DOCTYPE html>
<html>
<head>
	<title>Modifier</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="styl.css">
</head>
<body>
	<div class="container">
		<form action="php/update2.php" 
		      method="post">
            
		   <h4 class="display-4 text-center">Modifier</h4><hr><br>
		   <?php if (isset($_GET['error'])) { ?>
		   <div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
		    </div>
		   <?php } ?>
		   <div class="form-group">
		     <label for="name">Nom de l'utilisateur</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="username" 
		           value="<?=$row['username'] ?>" >
		   </div>
		   

		   <div class="form-group">
		     <label for="email">Mot de passe</label>
		     <input type="name" 
		           class="form-control" 
		           id="email" 
		           name="password" 
		           value="<?=$row['password'] ?>" >
		   </div>
		   <div class="form-group">
		     <label for="name">Role</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="name" 
		           value="<?=$row['name'] ?>" >
		   </div>
		   
		   <input type="text" 
		          name="user_id"
		          value="<?=$row['user_id']?>"
		          hidden >

		   <button type="submit" 
		           class="btn btn-primary"
		           name="update">Modifier</button>
		    <a href="read2.php" class="link-primary">Visualiser</a>
	    </form>
	</div>
</body>
</html>