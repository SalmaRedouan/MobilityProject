
<?php  

include "db_conn.php";

$sql = "SELECT * FROM offre ORDER BY id DESC";
$result = mysqli_query($conn, $sql);?>



<!DOCTYPE html>
<html>
<head>
<title>Create</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="css.css">
<link rel="stylesheet" href="homepage.css">
</head>
<body>
<div class="nav-links"id="navLinks">
            <i class="fa fa-times" onclick="hideMenu()"></i>

         <ul>
             <li><a href="homeConseil.php">Page d'accueil </a></li>
            
             <li><a href="logout.php">Déconnexion</a></li>
    
         </ul>



         </div>
<div class="container">
<div class="box">
<h4 class="display-4 text-center">Visualiser</h4><br>
<?php if (isset($_GET['success'])) { ?>
<div class="alert alert-success" role="alert">
<?php echo $_GET['success']; ?>
</div>
<?php } ?>
<?php if (mysqli_num_rows($result)) { ?>
<table class="table table-striped">
<thead>
<tr>
<th scope="col"> </th>
<th scope="col">Name</th>
<th scope="col">Email</th>
<th scope="col">Option</th>
<th scope="col">Nombre de place</th>
<th scope="col">Commentaire</th>
<th scope="col">Type de mobilité</th>
<th scope="col">Observations</th> 
<th scope="col">Filières concernées</th> 
<th scope="col">Nombre de place par filière respectivement</th> 


<th scope="col">Action</th>
</tr>
</thead>
<tbody>
<?php
$i = 0;
while($rows = mysqli_fetch_assoc($result)){
$i++;
?>
<tr>
<th scope="row"><?=$i?></th>
<td><?=$rows['name']?></td>
<td><?php echo $rows['email']; ?></td>
<td><?=$rows['option']?></td>
<td><?=$rows['nombre']?></td>
<td><?=$rows['comment']?></td>
<td><?=$rows['type']?></td>
<td><?=$rows['observation']?></td>
<td><?=$rows['choix']?></td>
<td><?=$rows['nb']?></td>
<td><a href="updateC.php?id=<?=$rows['id']?>"
class="btn btn-success">Affectation</a>


</td>
</tr>
<?php } ?>
</tbody>
</table>
<?php } ?>
<div class="link-right">
<a href="homeConseil.php" class="link-primary">Enregistrer</a>
</div>
</div>
</div>
</body>
</html>

