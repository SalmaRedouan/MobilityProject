
<?php include "php/finalS.php"; ?>
<?php  

include "db_conn.php";

$sql ="SELECT * FROM offre where choix LIKE '%SMART%' or 'SMART%' or '%SMART'   ORDER BY id DESC";
$result = mysqli_query($conn, $sql);?>
<!DOCTYPE html>
<html>
<head>
<title>Create</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


<link rel="stylesheet"   href="style.css">

</head>
<body>
<section class="header">
    <nav>
        
     


         <div class="nav-links"id="navLinks">
            <i class="fa fa-times" onclick="hideMenu()"></i>
         <ul>
             <li><a href="DATA.php">Page d'accueil </a></li>
            
             <li><a href="logout.php">Déconnexion</a></li>
    
         </ul>
         </div></section>
<div class="container">
<div class="box">
<h4 class="display-4 text-center">Visualiser</h4><br>
<?php if (isset($_GET['success'])) { ?>
<div class="alert alert-success" role="alert">
<?php echo $_GET['success']; ?>
</div>
<?php } ?>
<?php if (mysqli_num_rows($result)) { ?>
    <div>
<table class="table table-striped">
<thead>
<tr>
<th scope="col">  </th>
<th scope="col">Name</th>
<th scope="col">Email</th>
<th scope="col">Option</th>
<th scope="col">Type de mobilité</th>
<th scope="col">Observations</th> 
</div>


</tr>
</thead>
<tbody>
<?php
$i = 0;
while($rows = mysqli_fetch_assoc($result)){
$i++;
?>
<tr>
<th scope="row"><?=$i?></th>
<td><?=$rows['name']?></td>
<td><?php echo $rows['email']; ?></td>
<td><?=$rows['option']?></td>

<td><?=$rows['type']?></td>
<td><?=$rows['observation']?></td>

</tr>
<?php } ?>
</tbody>
</table>
<?php } ?>
<div class="link-right">

</div>
</div>
</div>
<div class="sanae"><div class="salma">
      <form id="form" enctype="multipart/form-data"  action="php/finalS.php" 
		      validate()" method="post">
        <h3>Veuillez ordonner vos choix</h3> <br>
        <label>Nom et prénom <span>*</span></label><br>
        <input type="text" id="name" name="nom" placeholder="Nom et prénom en majiscule"/><br>
        
        <label>Destinataire <span>*</span></label> <br>
        
<SELECT name="destinataire" size="1">
<OPTION>Mme MARGHOUBI RABIA
<OPTION>M.El ISSATI OUSSAMA
<OPTION>M.BAINA AMINE
<OPTION>M.EL KHADIMI AHMED
<OPTION>M.EN-NOUAARY ABDSlAM
<OPTION>M.EL KHADIMI AHMED
<OPTION>M.BELMEKKI ABDELHAMID   
<OPTION>M.OUBRICH MOURAD
</SELECT> <br> <br>
        <label>Message:<span>*</span></label> <br>
        <textarea id="message" name="message" placeholder="Veuillez ordonner vos choix d'offre , je veux en premier lieu l'option...de l'école..., en nème lieu ... "></textarea><br>
        <button type="submit" 
		          class="btn btn-primary"
		          name="create">Envoyer message </button>
                  </div></form>
      </div>
</body>
</html>

