<!DOCTYPE html>
<html>
<head>
	<title>Dépôt des offres </title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="styl.css">
</head>
<body>
	<div class="container">
		<form action="php/create2.php" 
		      method="post">
            
		   <h4 class="display-4 text-center">Mon tableau de bord </h4><hr><br>
		   <?php if (isset($_GET['error'])) { ?>
		   <div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
		    </div>
		   <?php } ?>
		   <div class="form-group">
		     <label for="name">Nom de l'utilisateur</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="username" 
		           value="<?php if(isset($_GET['username']))
		                           echo($_GET['username']); ?>" 
		           placeholder="Enter name">
		   </div>

		   <div class="form-group">
		     <label for="email">Mot de passe</label>
		     <input type="name" 
		           class="form-control" 
		           id="email" 
		           name="password" 
		           value="<?php if(isset($_GET['password']))
		                           echo($_GET['password']); ?>"
		           placeholder="Enter password">
		   </div>
		   <div class="form-group">
		     <label for="email">Rôle </label>
		     <input type="text" 
		           class="form-control" 
		           id="email" 
		           name="name" 
		           value="<?php if(isset($_GET['name']))
		                           echo($_GET['name']); ?>"
		           placeholder="Enter ID">
		   </div>
		  

		   <button type="submit" 
		          class="btn btn-primary"
		          name="create">Enregistrer</button>
		    <a href="read2.php" class="link-primary">Visualiser</a>
	    </form>
	</div> <br>
	<table class="code" width="20%" box-size:"100px" border="1" cellspacing="1" cellpadding="5">
<thead>
<tr>
<th width="20%">Utilisateur </td>
<th>Rôle</td>
</tr>
</thead>
<tbody>
<tr>
<td>Administrateur de l'appliction</td>
<td>1</td>
</tr>
<tr>
<td>Collecteur d'offres</td>
<td>2</td>
</tr>
<tr>
<td>Conseil de département </td>
<td>4</td>
</tr>
<tr>
<td>Cordinateur</td>
<td>3</td>
</tr>
<tr>
<td>DATA</td>
<td>5</td>
</tr>
<tr>
<td>AMOA</td>
<td>6</td>
</tr>
<tr>
<td>SISNUM</td>
<td>7</td>
</tr>

<tr>
<td>ASEDS</td>
<td>8</td>
</tr>
<tr>
<td>CLOUD</td>
<td>9</td>
</tr>
<tr>
<td>ICCN</td>
<td>10</td>
</tr>
<tr>
<td>SMART</td>
<td>11</td>
</tr>
</tbody>
</table>
</body>
</html>