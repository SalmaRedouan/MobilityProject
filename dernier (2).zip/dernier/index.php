<!DOCTYPE html>
<html>
<head>
	<title>Dépôt des offres </title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" href="styl.css">
</head>
<body>
	<div class="container">
		<form action="php/create.php" 
		      method="post">
            
		   <h4 class="display-4 text-center">Veuillez déposer les offres de mobilité </h4><hr><br>
		   <?php if (isset($_GET['error'])) { ?>
		   <div class="alert alert-danger" role="alert">
			  <?php echo $_GET['error']; ?>
		    </div>
		   <?php } ?>
		   <div class="form-group">
		     <label for="name">Nom de l'école</label>
		     <input type="name" 
		           class="form-control" 
		           id="name" 
		           name="name" 
		           value="<?php if(isset($_GET['name']))
		                           echo($_GET['name']); ?>" 
		           placeholder="Enter name">
		   </div>

		   <div class="form-group">
		     <label for="email">Email de l'école </label>
		     <input type="email" 
		           class="form-control" 
		           id="email" 
		           name="email" 
		           value="<?php if(isset($_GET['email']))
		                           echo($_GET['email']); ?>"
		           placeholder="Enter email">
		   </div>
		   <div class="form-group">
		     <label for="email">Option </label>
		     <input type="text" 
		           class="form-control" 
		           id="email" 
		           name="option" 
		           value="<?php if(isset($_GET['option']))
		                           echo($_GET['option']); ?>"
		           placeholder="Enter l'option">
		   </div>
		   <div class="form-group">
		     <label for="email">Nombre de place  </label>
		     <input type="text" 
		           class="form-control" 
		           id="email" 
		           name="nombre" 
		           value="<?php if(isset($_GET['nombre']))
		                           echo($_GET['nombre']); ?>"
		           placeholder="Entrer le nombre de place par option ">
		   </div>
		   <div class="form-group">
		     <label for="email">Commentaire</label>
		     <input type="text" 
		           class="form-control" 
		           id="email" 
		           name="comment" 
		           value="<?php if(isset($_GET['comment']))
		                           echo($_GET['comment']); ?>"
		           placeholder="veuillez commenter l'option ">
		   </div>
		   <div class="form-group">
		     <label for="email">Type de mobilité</label>
		     <input type="text" 
		           class="form-control" 
		           id="email" 
		           name="type" 
		           value="<?php if(isset($_GET['type']))
		                           echo($_GET['type']); ?>"
		           placeholder="Entrer le type de mobilité">
		   </div>
		   <div class="form-group">
		     <label for="email">Observations </label>
		     <input type="message" 
		           class="form-control" 
		           id="email" 
		           name="observation" 
		           value="<?php if(isset($_GET['observation']))
		                           echo($_GET['observation']); ?>"
		           placeholder="Entrer votre observation">
		   </div>

		   <button type="submit" 
		          class="btn btn-primary"
		          name="create">Enregistrer</button>
		    <a href="read.php" class="link-primary">Visualiser</a>
	    </form>
	</div>
</body>
</html>