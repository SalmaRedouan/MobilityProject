


*{
    margin:0;
    padding:0;


}

body{
	min-height: 100vh;
	width:100%;
    background-image:linear-gradient(rgba(4,9,30,0.7),rgba(4,9,30,0.7)),
     url("sanae.jpeg");
    background-position: center;
    background-size: cover;
    
    position: relative; }

.container {
	min-height: 100vh;
	display: flex;
	justify-content: center;
	align-items: center;
	flex-direction: column;
    }

.container form {
	width: 500px;
	padding: 20px;
	border-radius: 10px;
    
	box-shadow: 0 4px 8px 0 rgba(228, 169, 169, 0.2), 0 6px 20px 0 rgba(250, 242, 242, 0.19);
}
.box {
	width: 750px;
}
.container table {
	padding: 20px;
	border-radius: 10px;
	box-shadow: 0 4px 8px 0 rgba(236, 232, 232, 0.2), 0 6px 20px 0 rgba(250, 249, 249, 0.19);
}
.link-right {
	display: flex;
	justify-content: flex-end;
}
h4{
    width: 100%;
    margin: 10px;
    color: #fff;
    text-align: center;
    font-style: inherit;
    font-weight: bold;
    
    }
   .form-control {
    width: 100%;
    margin: 10px;
    outline: none;
    background-color: transparent;

    padding: 10px 6px;
    font-weight: bold;
    box-sizing: border-box;
    border: none;
    border-bottom: 1px #fff solid;
    color: rgb(206, 206, 200);
   
    
   }
   .form-group{
    
    font-weight: bold;
   
  
    color: rgba(255, 255, 255, 0.993);
   }
   .link-primary{

   text-decoration: none;
cursor: pointer;
size: 55px;
font-weight: bold;
color: rgb(103, 136, 245);
   }
   
  
   .table table-striped{
 color: #fff;

   }

   
   th{
       color:white;
       text-align: center;

font-weight: bold;
       
   }
   td{
       color: antiquewhite;
   }
   .link-primary{
       font-weight: 1000;
       font-size: large;
       color: white;
   }
  