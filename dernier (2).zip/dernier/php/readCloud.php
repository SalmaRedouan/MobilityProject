
<?php  

include "db_conn.php";

$sql = "SELECT * FROM offre where UPPER(filiere) = UPPER('cloud) ORDER BY id DESC";
$result = mysqli_query($conn, $sql);?>



<!DOCTYPE html>
<html>
<head>
<title>Create</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<link rel="stylesheet" href="styl.css">
</head>
<body>
<div class="container">
<div class="box">
<h4 class="display-4 text-center">Visualiser</h4><br>
<?php if (isset($_GET['success'])) { ?>
<div class="alert alert-success" role="alert">
<?php echo $_GET['success']; ?>
</div>
<?php } ?>
<?php if (mysqli_num_rows($result)) { ?>
<table class="table table-striped">
<thead>
<tr>
<th scope="col">#</th>
<th scope="col">Name</th>
<th scope="col">Email</th>
<th scope="col">Option</th>
<th scope="col">Nombre de place</th>
<th scope="col">Type de mobilité</th>
<th scope="col">Observations</th> 
<th scope="col">Ordre de priorité</th> 




<th scope="col">Action</th>
</tr>
</thead>
<tbody>
<?php
$i = 0;
while($rows = mysqli_fetch_assoc($result)){
$i++;
?>
<tr>
<th scope="row"><?=$i?></th>
<td><?=$rows['name']?></td>
<td><?php echo $rows['email']; ?></td>
<td><?=$rows['option']?></td>
<td><?=$rows['nombre']?></td>
<td><?=$rows['type']?></td>
<td><?=$rows['observation']?></td>
<td><?=$rows['ordre']?></td>
<td><?=$rows['prenom']?></td>

<td><a href="updateS.php?id=<?=$rows['id']?>"
class="btn btn-success">ordonner</a>


</td>
</tr>
<?php } ?>
</tbody>
</table>
<?php } ?>
<div class="link-right">
<a href="CLOUD.php" class="link-primary">Enregistrer</a>

</div>
</div>
</div>
</body>
</html>

