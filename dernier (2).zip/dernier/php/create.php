<?php 

if (isset($_POST['create'])) {
	include "../db_conn.php";
	function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$name = validate($_POST['name']);
	$email = validate($_POST['email']);
	$option = validate($_POST['option']);
	$nombre = validate($_POST['nombre']);
	$comment = validate($_POST['comment']);
	$type = validate($_POST['type']);
	$observation = validate($_POST['observation']);

	$user_data = 'name='.$name. '&email='.$email. '&option='.$option. '&nombre='.$nombre. '&comment='.$comment. '&type='.$type. '&observation='.$observation;

	if (empty($name)) {
		header("Location: ../index.php?error=Nom de l'école est obligatoire &$user_data");
	}else if (empty($email)) {
		header("Location: ../index.php?error=Email est obligatoire &$user_data");
	}else if (empty($option)) {
		header("Location: ../index.php?error=Option est obligatoire&$user_data");
	}else if (empty($nombre)) {
			header("Location: ../index.php?error=Veuillez remplir la case : nombre de place&$user_data");		
	}else if (empty($type)) {
				header("Location: ../index.php?error=Option est obligatoire&$user_data");
	}else if (empty($observation)) {
					header("Location: ../index.php?error=Observation est obligatoire&$user_data");
	}else {

       $sql = "INSERT INTO offre(name, email,option,nombre,comment,observation,type) 
               VALUES('$name', '$email', '$option', '$nombre','$comment', '$observation', '$type')";
       $result = mysqli_query($conn, $sql);
       if ($result) {
       	  header("Location: ../read.php?success=Création réussie");
       }else {
          header("Location: ../index.php?error=erreur&$user_data");
       }
	}

}