<?php 

if (isset($_POST['create'])) {
	include "../db_conn.php";
	function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$username = validate($_POST['username']);
	$password = validate($_POST['password']);
	$name= validate($_POST['name']);
	

	$user_data = 'username='.$username. '&password='.$password. '&name='.$name;

	if (empty($username)) {
		header("Location: ../index2.php?error=Nom de l'utilisateur est obligatoire &$user_data");
	}else if (empty($password)) {
		header("Location: ../index2.php?error=Mot de passe  est obligatoire &$user_data");
	}else if (empty($name)) {
		header("Location: ../index2.php?error=Id est obligatoire&$user_data");
	}
    else {

       $sql = "INSERT INTO users (username, password,name) 
               VALUES('$username', '$password', '$name')";
       $result = mysqli_query($conn, $sql);
       if ($result) {
       	  header("Location: ../read2.php?success=Création réussie");
       }else {
          header("Location: ../index2.php?error=erreur&$user_data");
       }
	}

}