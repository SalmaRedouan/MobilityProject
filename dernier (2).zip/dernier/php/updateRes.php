<?php 

if (isset($_GET['id'])) {
	include "db_conn.php";

	function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$id = validate($_GET['id']);

	$sql = "SELECT * FROM inscription WHERE id=$id";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
    	$row = mysqli_fetch_assoc($result);
    }else {
    	header("Location: readTcordi.php");
    }


}else if(isset($_POST['update'])){
    include "../db_conn.php";
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$nom = validate($_POST['nom']);
	$destinataire = validate($_POST['destinataire']);
        $message= validate($_POST['message']);
        $resultat = validate($_POST['resultat']);
        
	$id = validate($_POST['id']);

	if (empty($nom)) {
		header("Location: ../update.php?id=$id&error=Nom de l'école est obligatoire");
	}else if (empty($destinataire)) {
		header("Location: ../update.php?id=$id&error=Email de l'école est obligatoire");
	}
        else if (empty($message)) {
		header("Location: ../update.php?id=$id&error=veuillez remplir la case : option ");
	}
        else if (empty($resultat)) {
		header("Location: ../update.php?id=$id&error=Votre selection est  obligatoire ");
	}
        
        else {

       $sql = "UPDATE inscription
               SET resultat ='$resultat'
               WHERE id=$id ";
       $result = mysqli_query($conn, $sql);
       if ($result) {
       	  header("Location: ../visualiserFinal.php?success=Votre affectation a été bien enregistrée, merci!");
       }else {
          header("Location: ../updateRes.php?id=$id&error=erreur&$user_data");
       }
	}
}else {
	header("Location: VisualiserFinal.php");
}