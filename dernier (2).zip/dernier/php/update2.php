<?php 

if (isset($_GET['user_id'])) {
	include "db_conn.php";

	function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$user_id = validate($_GET['user_id']);

	$sql = "SELECT * FROM users WHERE user_id=$user_id";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
    	$row = mysqli_fetch_assoc($result);
    }else {
    	header("Location: read2.php");
    }


}else if(isset($_POST['update'])){
    include "../db_conn.php";
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$username = validate($_POST['username']);
	$password= validate($_POST['password']);
        $name = validate($_POST['name']);
        
	$user_id = validate($_POST['user_id']);

	if (empty($username)) {
		header("Location: ../update2.php?user_id=$user_id&error=Nom de l'utilisateur est obligatoire");
	}else if (empty($password)) {
		header("Location: ../update2.php?user_id=$user_id&error=Le mot de passe est obligatoire");
	}
        else if (empty($name)) {
		header("Location: ../update2.php?user_id=$user_id&error=le role est obligatoire ");
	}
       
        else {

       $sql = "UPDATE users
               SET username ='$username', password='$password', name='$name'
               WHERE user_id=$user_id ";
       $result = mysqli_query($conn, $sql);
       if ($result) {
       	  header("Location: ../read2.php?success=Modification réussie");
       }else {
          header("Location: ../update2.php?user_id=$user_id&error=erreur&$user_data");
       }
	}
}else {
	header("Location: read2.php");
}