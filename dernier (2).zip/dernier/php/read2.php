<?php  

include "db_conn.php";

$sql = "SELECT * FROM users  ORDER BY user_id DESC";
$result = mysqli_query($conn, $sql);