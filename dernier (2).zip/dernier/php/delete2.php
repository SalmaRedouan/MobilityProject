<?php  

if(isset($_GET['user_id'])){
   include "../db_conn.php";
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$user_id = validate($_GET['user_id']);

	$sql = "DELETE FROM users
	        WHERE user_id=$user_id";
   $result = mysqli_query($conn, $sql);
   if ($result) {
   	  header("Location: ../read2.php?success=Suppression réussie");
   }else {
      header("Location: ../read2.php?error=erreur&$user_data");
   }

}else {
	header("Location: ../read2.php");
}