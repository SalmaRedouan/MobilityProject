<?php 

if (isset($_GET['id'])) {
	include "db_conn.php";

	function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$id = validate($_GET['id']);

	$sql = "SELECT * FROM offre WHERE id=$id";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
    	$row = mysqli_fetch_assoc($result);
    }else {
    	header("Location: read.php");
    }


}else if(isset($_POST['update'])){
    include "../db_conn.php";
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$name = validate($_POST['name']);
	$email = validate($_POST['email']);
        $option = validate($_POST['option']);
        $nombre = validate($_POST['nombre']);
        $comment = validate($_POST['comment']);
        $type = validate($_POST['type']);
        $observation = validate($_POST['observation']);
	$id = validate($_POST['id']);

	if (empty($name)) {
		header("Location: ../update.php?id=$id&error=Nom de l'école est obligatoire");
	}else if (empty($email)) {
		header("Location: ../update.php?id=$id&error=Email de l'école est obligatoire");
	}
        else if (empty($option)) {
		header("Location: ../update.php?id=$id&error=veuillez remplir la case : option ");
	}
        else if (empty($nombre)) {
		header("Location: ../update.php?id=$id&error=Nombre de place est obligatoire ");
	}
        else if (empty($type)) {
		header("Location: ../update.php?id=$id&error=Type de mobilité est obligatoire ");
	}
        else if (empty($observation)) {
		header("Location: ../update.php?id=$id&error=Observation est obligatoire");
	}
        else {

       $sql = "UPDATE offre
               SET name ='$name', email='$email', option='$option', nombre='$nombre', comment='$comment', type='$type', observation='$observation'
               WHERE id=$id ";
       $result = mysqli_query($conn, $sql);
       if ($result) {
       	  header("Location: ../read.php?success=Modification réussie");
       }else {
          header("Location: ../update.php?id=$id&error=erreur&$user_data");
       }
	}
}else {
	header("Location: read.php");
}