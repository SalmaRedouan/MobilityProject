<?php 

if (isset($_GET['id'])) {
	include "db_conn.php";

	function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}
        

	$id = validate($_GET['id']);

	$sql = "SELECT * FROM offre WHERE id=$id";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
    	$row = mysqli_fetch_assoc($result);
    }else {
    	header("Location: readCo.php");
    }


}else if(isset($_POST['update'])){
    include "../db_conn.php";
    function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}
            $connaitre_array = ( isset($_POST['connaitre']) )? $_POST['connaitre'] : ''; 
            $connaitre_list = implode( ',', $connaitre_array); // implode pour mettre à la suite les pièces de ton tableau dans une chaine de caractères en les séparant par un délimiteur
     
            $connaitre_a = ( isset($_POST['nb']) )? $_POST['nb'] : ''; 
            $connaitre_l = implode( ',', $connaitre_a); // implode pour mettre à la suite les pièces de ton tableau dans une chaine de caractères en les séparant par un délimiteur
     
	$name = validate($_POST['name']);
	$email = validate($_POST['email']);
        $option = validate($_POST['option']);
        $nombre = validate($_POST['nombre']);
        $comment = validate($_POST['comment']);
        $type = validate($_POST['type']);
        $observation = validate($_POST['observation']);
	$id = validate($_POST['id']);
        var_dump( $connaitre_array ); // TEST
        echo $connaitre_list;

	if (empty($name)) {
		header("Location: ../updateC.php?id=$id&error=Nom de l'école est obligatoire");
	}else if (empty($email)) {
		header("Location: ../updateC.php?id=$id&error=Email de l'école est obligatoire");
	}
        else if (empty($option)) {
		header("Location: ../updateC.php?id=$id&error=veuillez remplir la case : option ");
	}
        else if (empty($nombre)) {
		header("Location: ../updateC.php?id=$id&error=Nombre de place est obligatoire ");
	}
        else if (empty($type)) {
		header("Location: ../updateC.php?id=$id&error=Type de mobilité est obligatoire ");
	}
        else if (empty($observation)) {
		header("Location: ../updateC.php?id=$id&error=Observation est obligatoire");
	}
    else if (empty($connaitre_list)) {
		header("Location: ../updateC.php?id=$id&error=filiere  est obligatoire");
	}
        else {

       $sql = "UPDATE offre
               SET choix='$connaitre_list',nb='$connaitre_l'
               WHERE id=$id ";
       $result = mysqli_query($conn, $sql);
       if ($result) {
       	  header("Location: ../readCo.php?success=Modification réussie");
       }else {
          header("Location: ../updateC.php?id=$id&error=erreur&$user_data");
       }
	}
}else {
	header("Location: readCo.php");
}