<?php  

include "db_conn.php";

$sql = "SELECT * FROM offre ORDER BY id DESC";
$result = mysqli_query($conn, $sql);