<?php 

if (isset($_POST['create'])) {
	include "../db_conn.php";
	function validate($data){
        $data = trim($data);
        $data = stripslashes($data);
        $data = htmlspecialchars($data);
        return $data;
	}

	$nom = validate($_POST['nom']);
	$destinataire = validate($_POST['destinataire']);
	$message = validate($_POST['message']);


	$user_data = 'nom='.$nom. '&destinataire='.$destinataire. '&message='.$message ;

	if (empty($nom)) {
		header("Location: ../readE1.php?error=votre nom est obligatoire&$user_data");
	}else if (empty($destinataire)) {
		header("Location: ../readE1.php?error=choisir un destinataire&$user_data");
	}else if (empty($message)) {
		header("Location: ../readE1.php?error=Veuillez écrire votre message&$user_data");
	}
  else {

       $sql = "INSERT INTO inscription(nom, destinataire,message) 
               VALUES('$nom', '$destinataire', '$message')";
       $result = mysqli_query($conn, $sql);
       if ($result) {
        header("Location: ../readE1.php?success=Votre message a été bien envoyé,merci!");
       	 echo "Envoi réussi";
       }else {
          header("Location: ../readE1.php?error=erreur&$user_data");
       }
	}

}

