<?php
include('dbcon.php');
include('session.php');

$result=mysqli_query($con, "select * from users where user_id='$session_id'")or die('Error In Session');
$row=mysqli_fetch_array($result);

?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>home page of mobility </title>
    <link rel="stylesheet"   href="homepage.css">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Fira+Sans+Condensed:ital,wght@0,300;0,500;0,600;1,800&display=swap" rel="stylesheet">
<link rel="stylesheet"href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
 <section class="header">
    <nav>
        <a href="http://www.inpt.ac.ma/"><img src="image111.jpg"></a>
     


         <div class="nav-links"id="navLinks">
            <i class="fa fa-times" onclick="hideMenu()"></i>

         <ul>
             <li><a href="">Page d'accueil </a></li>
             <li><a href="https://www.inpt.ac.ma/fr/Mobilit%C3%A9">À propos </a></li>
             <li><a href="readTcordi.php">Offres</a></li>
             <li><a href="readChoixE.php">Affectation finale</a></li>
  
             <li><a href="logout.php">Déconnexion</a></li>

    
         </ul>



         </div>
              <i class="fa fa-bars"onclick="showMenu()"></i>

     </nav>
     <div class="text-box">
 <center><h2 style="color:#ff9999;">bienvenue  <?php echo $row['username']; ?> </h2></center>
           <h1>Mobilité des étudiants </h1>
               <h3>INPT : des ingénieurs de dimension internationale</h3>
           <p>
            Etre mobile, multilingue et familiarisé avec d’autres cultures, constituent des atouts qui font aujourd’hui la différence dans une carrière d’ingénieur. C’est ainsi que l’INPT s’attache à développer la mobilité culturelle et intellectuelle de ses étudiants.<br>

            Cette mobilité se fait dans le cadre d'accords d'échange avec des universités et écoles partenaires de l’INPT. Les étudiants de 2ème année du cycle ingénieur postulent aux programmes d’échanges proposés par nos établissements partenaires. Ces derniers leur offrent l’opportunité de passer une à deux années d’études, pour valider la troisième année de leur cursus et / ou faire au choix un master ou un programme de double diplôme.
</p>
     <a href="https://www.google.com/url?sa=t&source=web&rct=j&url=https://www.inpt.ac.ma/fr/Mobilit%25C3%25A9&ved=2ahUKEwjTsv3zr-fwAhUU7aQKHUr_AWoQFjAMegQIBhAC&usg=AOvVaw1P_Xlo-ExGyLMR3L5mV6e4" class="hero-btn">Pour plus d'infos..</a>
    
     </div>


 </section>  
<!----------nos offres de mobilité---------->
<section class="mobilité">
<h1>Les mobilités offertes </h1>
<div class="row">
    <div class="mobilité-col">
        <h3>Semestres en échange</h3>
        <p>Il s’agit de partir étudier un semestre ou une année dans une université/école étrangère, dans la même discipline que celle suivie à l’INPT.</p>
    </div><div class="mobilité-col">
            <h3>Double Diplôme</h3>
            <p>Un cursus double-diplômant permet à nos élèves ingénieurs d’obtenir le diplôme de l’établissement partenaire, en plus du diplôme d’ingénieur d’Etat de l’INPT.
    
            </p></div>
            <div class="mobilité-col">
                <h3>Stages à l’étranger</h3>
                <p>Les étudiants de l’INPT, peuvent à leurs demandes, effectuer plusieurs types de stages durant leur cursus : des stages en laboratoires universitaires ou des stages en entreprises ou organismes internationaux.
        
                </p>
    </div>
</div>


</section>


 <!-----Javascript for toggle Menu-------->
 <script>
     var navLinks=document.getElementById("navLinks");
     function showMenu(){
         navLinks.style.right="0";
     }
     function hideMenu(){
         navLinks.style.right="-200px"; 
     }
     
 </script>
</body>
</html>